/**
 * @Author David U, Yenci V, William M, Manual M
 */
public class Factura {

    /**
     * Atributo para la cantidad en la familia
     */
    public Integer cantidad;

    /**
     * Atributo para el paquete de la habitacion
     */
    public String paquete;

    /**
     * Atributo para la cantidad de dias de la estadia
     */
    public Integer dias;

    /**
     * Atributo para saber la nacionalidad de la familia
     */
    public String extraNacio;

    /**
     * Atributo para agregar la clase de la familia
     */
    public Familia laFamilia;

    /**
     * <p>Constructor de la clase Bodega</p>
     * @param cantidad
     * @param paquete
     * @param dias
     * @param extraNacio
     */
    public Factura(Integer cantidad, String paquete, Integer dias, String extraNacio) {
        this.cantidad = cantidad;
        this.paquete = paquete;
        this.dias = dias;
        this.extraNacio = extraNacio;
        this.laFamilia = new Familia("", "", "");
    }

    public String getPaquete() {
        return this.paquete;
    }

    public void setPaquete(String paquete) {
        this.paquete = paquete;
    }

    public Integer getDias() {
        return this.dias;
    }

    public void setDias(Integer dias) {
        this.dias = dias;
    }

    public Integer getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public String getExtraNacio() {
        return this.extraNacio;
    }

    public void setExtraNacio(String extraNacio) {
        this.extraNacio = extraNacio;
    }

    public Familia getLaFamilia() {
        return this.laFamilia;
    }

    public void setLaFamilia(Familia laFamilia) {
        this.laFamilia = laFamilia;
    }

    /**
     * Atributos para el metodo
     */

    Integer preciPaque = 0;
    double porcen;
    double total;

    /**
     * <p>
     *     Para mostrar el total de la factura
     * </p>
     */
    public double facturar() {
        if (this.paquete.equals("STANDARD")) {
            this.preciPaque = 150;
        } else if (this.paquete.equals("DELUXE")) {
            this.preciPaque = 350;
        } else if (this.paquete.equals("VIP")) {
            this.preciPaque = 1000;
        }

        this.total = (double)(this.preciPaque * this.cantidad * this.dias);
        if (this.extraNacio.equals("SI")) {
            this.porcen = this.total * 0.25;
            this.total += this.porcen;
        }

        return this.total;
    }
}
