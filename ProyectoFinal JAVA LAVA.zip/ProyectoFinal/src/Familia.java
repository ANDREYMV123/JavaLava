/**
 * @Author David U, Yenci V, William M, Manual M
 */
public class Familia
{
    /**
     * Atributo para el nombre de la familia
     */
    public String nomFam;

    /**
     * Atributo para la direccion en la familia
     */
    public String direFam;

    /**
     * Atributo para los contactos en la familia
     */
    public String infoContacto;


    public Familia(String nomFam, String direFam, String infoContacto)
    {
        this.nomFam = nomFam;
        this.direFam = direFam;
        this.infoContacto = infoContacto;
    }

    public String getNomFam()
    {
        return nomFam;
    }

    public void setNomFam(String nomFam)
    {
        this.nomFam = nomFam;
    }

    public String getDireFam()
    {
        return direFam;
    }

    public void setDireFam(String direFam)
    {
        this.direFam = direFam;
    }

    public String getInfoContacto()
    {
        return infoContacto;
    }

    public void setInfoContacto(String infoContacto)
    {
        this.infoContacto = infoContacto;
    }
}
