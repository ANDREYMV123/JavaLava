import javax.swing.*;
/**
 * @Author David U, Yenci V, William M, Manual M
 */
public class HotelJavaLava
{
    public static void main(String[] args)
    {
        /**
         * Se crea el arreglo para las nuevas clases
         */
        Factura lasFacturas[] = new Factura[100];

        /**
         * Variables necesarias
         */
        String menu1 = "";
        double factura = 0.00;
        int contador = -1;
        String confirmacion = "";

        /**
         * Es es el menu en donde se controla todo
         */
        while (!menu1.equals("3"))
        {
            menu1 = JOptionPane.showInputDialog(null,"Bienvenido a la Isla JAVA Lava!\n\nMenu\n\n1. Agregar Familia\n2. Desglose de factura\n3. Salir");

            /**
             * Primera opcion
             */
            if (menu1.equals("1"))
            {
                /**
                 * Contador para los arreglos
                 */
                contador += 1;
                confirmacion = "";

                /**
                 * Se crea un Objeto de una clase
                 */
                lasFacturas[contador] = new Factura(0,"", 0, "");

                /**
                 * Se agrega toda la imformacion pertinente
                 */
                lasFacturas[contador].laFamilia.setNomFam(JOptionPane.showInputDialog(null, "Digite el nombre de la familia:"));

                lasFacturas[contador].laFamilia.setDireFam(JOptionPane.showInputDialog(null, "Digite la direccion de su familia:"));

                lasFacturas[contador].laFamilia.setInfoContacto(JOptionPane.showInputDialog(null, "Digite su informacion de contacto (Telefono/Correo):"));

                lasFacturas[contador].setCantidad(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de personas:")));

                lasFacturas[contador].setDias(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite la cantidad de dias:")));

                while (!lasFacturas[contador].paquete.equals("STANDARD") && !lasFacturas[contador].paquete.equals("DELUXE") && !lasFacturas[contador].paquete.equals("VIP"))
                {
                    lasFacturas[contador].setPaquete(JOptionPane.showInputDialog(null,"Escoja entre los paquetes STANDARD/DELUXE/VIP (Por favor escriba en mayúsculas):"));
                    if (!lasFacturas[contador].paquete.equals("STANDARD") && !lasFacturas[contador].paquete.equals("DELUXE") && !lasFacturas[contador].paquete.equals("VIP"))
                    {
                        JOptionPane.showMessageDialog(null,"Error, no se digito una opcion valida, intente de nuevo.");
                    }
                }

                while (!lasFacturas[contador].extraNacio.equals("SI") && !lasFacturas[contador].extraNacio.equals("NO"))
                {

                    lasFacturas[contador].setExtraNacio(JOptionPane.showInputDialog(null,"Su familia es extranjera? SI/NO (Por favor escriba en mayúsculas)"));
                    if (!lasFacturas[contador].extraNacio.equals("SI") && !lasFacturas[contador].extraNacio.equals("NO"))
                    {
                        JOptionPane.showMessageDialog(null,"Error, no se digito una opcion valida, intente de nuevo.");
                    }
                }

                factura = lasFacturas[contador].facturar();

                while (!confirmacion.equals("SI") && !confirmacion.equals("NO"))
                {
                    confirmacion = JOptionPane.showInputDialog(null, "El total a pagar es: $" + factura + "\n\n¿Desea confirmar su reservación? \nSI/NO (Por favor escriba en mayúsculas)");

                    if (confirmacion.equals("SI")) {
                        JOptionPane.showMessageDialog(null, "Entendido. \nPara obsevar el desglose de la factura, favor de ingresar en la opcion 2 del menu.");
                    } else if (confirmacion.equals("NO")) {
                        JOptionPane.showMessageDialog(null, "Entendido. \nFavor de ingresar la informacion de nuevo para un difierente precio.");
                        contador -= 1;
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Error, no se digito una opcion valida, intente de nuevo.");
                    }
                }
            }

            /**
             * Segunda opcion
             */
            else if (menu1.equals("2"))
            {
                if (contador > -1)
                {
                    JOptionPane.showMessageDialog(null, "--> Familia: " + lasFacturas[contador].laFamilia.nomFam + "\n\n--> Direccion: " +
                            lasFacturas[contador].laFamilia.direFam + "\n\n--> Contacto: " + lasFacturas[contador].laFamilia.infoContacto + "\n\n--> Dias: " + lasFacturas[contador].cantidad +
                            "\n\n--> Paquete: " + lasFacturas[contador].paquete + "\n\n--> Extranjero?: " + lasFacturas[contador].extraNacio + "\n\n--> Total: $" + factura);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"No hay informacion en la base de datos, intente de nuevo.");
                }
            }

            /**
             * Tercera opcion
             */
            else if (menu1.equals("3"))
            {
                JOptionPane.showMessageDialog(null,"Gracias por su visita!");
            }

            else
            {
                JOptionPane.showMessageDialog(null,"Error, no se digito una opcion valida, intente de nuevo.");
            }
        }
    }
}